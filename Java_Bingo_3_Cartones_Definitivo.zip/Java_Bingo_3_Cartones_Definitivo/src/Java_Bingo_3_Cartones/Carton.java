package Java_Bingo_3_Cartones;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Carton {
	// llamar a las imagenes de los cartones

	final static String Ruta = "C:\\Users\\ULISES III\\Desktop\\Instituto FP DUAL SUPERIOR\\01 Programación\\Ejercicios Java\\Java_Bingo_3_Cartones_Definitivo\\imgBingo";

	// Generar ImagenCartonBlanco

	ImageIcon MostrarCartonBlanco = new ImageIcon(Ruta + "cartonBingoEnBlanco.png");
	// Añadir CartonBlanco a la aplicacion
	JLabel JLabel_CartonBingoBlanco = new JLabel(MostrarCartonBlanco);

	public void MostrarCartonBlanco(JPanel Panel, int PosX, int PosY) {

		ImageIcon MostrarCartonBlanco = new ImageIcon(Ruta + "cartonBingoEnBlanco.png");
		JLabel_CartonBingoBlanco.setBounds(PosX, PosY, 600, 297);
		
		Panel.add(JLabel_CartonBingoBlanco);
		// TODO Auto-generated method stub

	}
	
}