
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.FileWriter;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;

public class VentanaWars extends JFrame implements ActionListener {

	// Metodo 0

	// Creacion de atributos

	public FileWriter ficheroVDA;

	final static String Ruta = "C:\\Users\\ULISES III\\Desktop\\Instituto FP DUAL SUPERIOR\\01 Programación\\Ejercicios Java\\Java_FrikisWars\\src\\ImgFrikiWars\\";

	ImageIcon Fondo = new ImageIcon(Ruta + "Fondo pantalla" + ".jpg");
	ImageIcon ImgCromo = new ImageIcon(Ruta + "traseraCromo" + ".jpg");

	ImageIcon FigurasPuestas = new ImageIcon(Ruta + "FiguraPuesta\\");
	ImageIcon FigurasAcertadas = new ImageIcon(Ruta + "FiguraAcertada\\");
	ImageIcon FiguraErronea = new ImageIcon(Ruta + "FiguraErronea\\");
	// Array de imagenes Acertadas y erroneas para un array de 10
	ImageIcon[] imagenesAcertadas;
	ImageIcon[] imagenesErroneas;

	ImageIcon[] imagenFigurasOcultas;

	ImageIcon[] imagenFiguraAleatoria;

	private static final long serialVersionUID = 1L;
	private static JPanel Panel;

	JLabel labelFondo = new JLabel();

	JLabel labelCromos01 = new JLabel();
	JLabel labelCromos02 = new JLabel();
	JLabel labelCromos03 = new JLabel();

	JLabel labelFigurasPuestas = new JLabel();
	JLabel labelFigurasAcertadas = new JLabel();
	JLabel labelFigurasErroneas = new JLabel();

	static JFrame Cuadro = new JFrame();
	static JPanel panel = (JPanel) Cuadro.getContentPane();

	static int contador = 0;
	int numeroPartidas = 0; // contador de partidas
	static int partidaJugadas = 0;

	//JButton
	
	JButton boton01 = new JButton("Aqui");
	JButton boton02 = new JButton("Aqui");
	JButton boton03 = new JButton("o Aqui");
	JButton botonReinciar = new JButton("Volver a Lanzar");
	
	//JLabel 
	
	JLabel labelImagenOculta1 = new JLabel();
	JLabel labelImagenOculta2 = new JLabel();
	JLabel labelImagenOculta3 = new JLabel();

	// Indices

	int numImagenAleatorio;

	int NumCromosAleatorios = 0;

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaWars frame = new VentanaWars();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	public VentanaWars() {
		/**
		 * @JFrame
		 **/
		setTitle("FrikiWars_By_Mad");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// X Y W H
		setBounds(0, 0, 810, 635);
		Panel = new JPanel();
		Panel.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(Panel);

		/**
		 * @param_Control: Absoluto
		 */
		Panel.setLayout(null);

		// llamar a los botones para que ingresen a Action Listener
		boton01.addActionListener(this);
		boton02.addActionListener(this);
		boton03.addActionListener(this);
		botonReinciar.addActionListener(this);

		/** Boton de la izquierda **/

		boton01.setBackground(new Color(192, 192, 192));
		boton01.setFont(new Font("Bahnschrift", Font.BOLD, 12));

		// Posicion del boton y tamaño
		boton01.setBounds(31, 529, 225, 35);
		Panel.add(boton01);
		Panel.add(labelCromos01);
		Panel.setComponentZOrder(boton01, 0);
		/** Boton de la izquierda **/

		boton02.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		boton02.setBounds(287, 529, 225, 35);

		boton02.setBackground(new Color(192, 192, 192));
		Panel.add(boton02);
		/** Boton de la izquierda **/

		boton03.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		boton03.setBounds(544, 529, 225, 31);

		boton03.setBackground(new Color(192, 192, 192));
		Panel.add(boton03);

		botonReinciar.setFont(new Font("Bahnschrift", Font.BOLD, 12));

		botonReinciar.setBounds(31, 563, 738, 30);
		Panel.add(botonReinciar);

		// Llamar a los metodos
		reiniciarJuego();
		inicializarImagenesOcultas(Ruta);
		mostrarImagenesOcultas();

		mostrarImagenes();
		inicializarImagenes();
		
		Cromos();
		fondodePantalla();
		crearFichero();
		// actionPerformed(null);
	}

	public void inicializarImagenesOcultas(String Ruta) {
		// TODO Auto-generated method stub
		int i = 0;
		int j = 0;
		imagenFigurasOcultas = new ImageIcon[10];
		// imagenesPuestas
		for (i = 0; i < 10; i++) {
			int numImagenAleatorio = (int) (Math.random() * 10) + 1;

			// Abreviar las rutas de las imagenes
			String imagenesAcertadas = ("FigurasAcertadas\\0" + (numImagenAleatorio) + "ok.jpg");
			// String imagenesErroneas = ("FiguraErronea\\0" + numImagenAleatorio +
			// "bad.jpg");
			imagenFigurasOcultas[i] = new ImageIcon(Ruta + imagenesAcertadas);
			// imagenFigurasOcultas[j] = new ImageIcon(Ruta + imagenesErroneas);

		}
	}

	private void mostrarImagenesOcultas() {
		// TODO Auto-generated method stub
		if (imagenFigurasOcultas.length == 0) {
			System.out.println("comprobamos que es 0");
			return;
		} else
			System.out.println("todo bien");

		// Genera un índice aleatorio dentro del rango de imágenes
		int indiceAleatorio = (int) (Math.random() * 3);
		ImageIcon imagenOculta = imagenFigurasOcultas[indiceAleatorio];
		System.out.println("\n Imagenes testeo ocultas :" + imagenFigurasOcultas);
		// Genera los Labels de las imagenes

	

		labelImagenOculta1.setIcon(imagenOculta);

		labelImagenOculta1.setBounds(31, 295, 225, 225);
		Panel.add(labelImagenOculta1);
		System.out.print("\n Mostrar imagenes ocultas 1 -->  " + imagenOculta);

		labelImagenOculta2.setIcon(imagenOculta);
		labelImagenOculta2.setBounds(287, 295, 225, 225);
		Panel.add(labelImagenOculta2);

		labelImagenOculta3.setIcon(imagenOculta);
		labelImagenOculta3.setBounds(544, 295, 225, 225);

		Panel.add(labelImagenOculta3);

	}
// borre el mouseaction

	public void fondodePantalla() {
		labelFondo.setIcon(Fondo);
		labelFondo.setBounds(0, 0, 810, 635);
		Panel.add(labelFondo);
		// labelFondo.getComponentZOrder(0);
	}

	public void Cromos() {
		labelCromos01.setIcon(ImgCromo);
		labelCromos01.setBounds(31, 295, 255, 255);
		// labelCromos01.getComponent(0);
		Panel.add(labelCromos01);

		labelCromos02.setIcon(ImgCromo);
		labelCromos02.setBounds(287, 295, 255, 255);
		Panel.add(labelCromos02);

		labelCromos03.setIcon(ImgCromo);
		labelCromos03.setBounds(544, 295, 255, 255);
		Panel.add(labelCromos03);

	}

	public void inicializarImagenes() {
		int i = 1;

		imagenFiguraAleatoria = new ImageIcon[10];
		// imagenesPuestas
		for (i = 0; i < 10; i++) {

			String imagenAleatorio = ("FiguraPuesta\\" + (i + 1) + 1 + "jpg");
			imagenFiguraAleatoria[i] = new ImageIcon(Ruta + imagenAleatorio);
		}

	}

	ImageIcon imagenFigurasPuesta = new ImageIcon();

	public void mostrarImagenes() {

		// imagen puesta
		int figuraAleatoria = (int) (Math.random() * 10);

		String rutaFiguras = "FiguraPuesta\\" + "0" + figuraAleatoria + ".jpg";

		imagenFigurasPuesta = new ImageIcon(Ruta + rutaFiguras);
		System.out.println("\n Figuras Puestas testeo" + imagenFigurasPuesta + "\n");

		labelFigurasPuestas.setIcon(imagenFigurasPuesta);
		labelFigurasPuestas.setBounds(288, 14, 225, 255);
		Panel.add(labelFigurasPuestas);

		// System.out.println(labelFigurasPuestas);

	}
	
	// metodo de imagenes para asociar las imagenes con los botones 
	
public  ImageIcon obtenerImagenBoton(JButton boton) {
        // Obtener la imagen asociada a un botón
        if (boton == boton01) {
            return (ImageIcon) boton01.getIcon();
        } else if (boton == boton02) {
            return (ImageIcon) boton02.getIcon();
        } else if (boton == boton03) {
            return (ImageIcon) boton03.getIcon();
        }
        return null;
    }
	
	public void intentoFallido() {
        // Mostrar mensaje de intento fallido
        verMensaje("¡Intento fallido!");



        // Si se supera el límite de intentos permitidos
        if (numeroPartidas > 10) {
            verMensaje("Has perdido la partida.");
            reiniciarJuego();
        }
        // Incrementar el contador de intentos
       numeroPartidas++;
       System.out.println(" test numero de partidas"+ numeroPartidas);
	}

	public void mostrarOpciones() {

		String opcionIgual;
		boolean opcionNegativa = false;
		boolean opcionPositiva = true;
	}

	// ------------------------------------------------------------------------------------

	private void verMensaje(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}

	private void reiniciarJuego(JLabel labelFigurasPuestas) {
		// Restablecer las imágenes y configuraciones iniciales directamente sobre los
		// componentes existentes

		inicializarImagenes();
		 /**panel.setComponentZOrder(labelImagenOculta1,0);
         panel.setComponentZOrder(labelImagenOculta2,0);
         panel.setComponentZOrder(labelImagenOculta3,0);**/
         labelFigurasPuestas.setComponentZOrder(panel,1);
		mostrarImagenes();
		// Refrescar el contenido del panel
		
		Panel.repaint();

	}

	// Crear fichero

	public void crearFichero() {
		FileWriter fichero;
		String salidaFichero;
		boolean resultado = false;

		salidaFichero = "Cromos Acertadas" + imagenFigurasPuesta + "-" + "Cromos Erroneas" + "-" + "Cromo" + "-"
				+ "Resultado" + resultado;

		try {
			fichero = new FileWriter("datosFrikisWars.VDA", true);

			fichero.write(salidaFichero);
			fichero.close();
		} catch (Exception ex) {

			System.out.println("Mensaje de la excepción: " + ex.getMessage());
		}
		System.out.println(salidaFichero);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		// boton 1
		if (event.getSource() == boton01 || event.getSource() == boton02 || event.getSource() == boton03) {
            // Obtener la imagen asociada al botón clicado
            ImageIcon imagenBoton = obtenerImagenBoton((JButton) event.getSource());
           /** panel.setComponentZOrder(labelImagenOculta1,1);
            panel.setComponentZOrder(labelImagenOculta2,1);
            panel.setComponentZOrder(labelImagenOculta3,1);**/
            // Verificar si la imagen acertada es igual a la imagen puesta
            if (imagenBoton.equals(imagenFigurasPuesta)) {
                verMensaje("¡Acertaste!");
                verMensaje("Ey mm  mm hemos llegado al fin pues !");
                reiniciarJuego(); // Reiniciar el juego después de un acierto para ir a la siguiente partida
            } else {
                intentoFallido(); // muentra un mensaje y permite otro intento si no se ha llegado al límite
            }
        } else if (event.getSource() == botonReinciar) {
            reiniciarJuego(); // Reiniciar el juego manualmente
        }
		// TODO Auto-generated method stub

		
	
	

		}
		// boton 2

		// boton 3

		// boton reiniciar

	

		
			
		

	}


