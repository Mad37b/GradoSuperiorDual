
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.MediaTracker;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;

public class VentanaWars extends JFrame implements ActionListener {

	// Metodo 0
	// Declara un objeto Random
	Random random = new Random();
	// Creacion de atributos

	public FileWriter ficheroVDA;
	public boolean aciertos;
	// Indices

	int numImagenAleatorio;

	int NumCromosAleatorios = 0;

	final static String Ruta = "C:\\Users\\ULISES III\\Desktop\\Instituto FP DUAL SUPERIOR\\01 Programación\\Ejercicios Java\\Java_FrikisWars\\src\\ImgFrikiWars\\";

	ImageIcon Fondo = new ImageIcon(Ruta + "Fondo pantalla" + ".jpg");
	ImageIcon ImgCromo = new ImageIcon(Ruta + "traseraCromo" + ".jpg");

	// Array de imagenes Acertadas y erroneas para un array de 10
	// Abreviar las rutas de las imagenes
	String rutaAcertadas = ("FigurasAcertadas\\0" + (numImagenAleatorio) + "ok.jpg");
	String rutaErroneas = ("FiguraErronea\\0" + (numImagenAleatorio) + "bad.jpg");

	ImageIcon[] imagenesFigurasOcultas;
	ImageIcon[] imagenesAcertadas;
	ImageIcon[] imagenesErroneas;
	ImageIcon[] imagenesAleatorias;
	ImageIcon[] imagenFiguraAleatoriaPuesta;

	private static final long serialVersionUID = 1L;

	JLabel labelFondo = new JLabel();

	JLabel labelCromos01 = new JLabel();
	JLabel labelCromos02 = new JLabel();
	JLabel labelCromos03 = new JLabel();

	JLabel labelFigurasPuestas = new JLabel();
	JLabel labelFigurasAcertadas = new JLabel();
	JLabel labelFigurasErroneas = new JLabel();

	static JFrame Cuadro = new JFrame();
	static JPanel Panel = (JPanel) Cuadro.getContentPane();

	static int contador = 0;
	int numeroPartidas = 0; // contador de partidas
	static int partidaJugadas = 0;

	// JButton

	JButton boton01 = new JButton("Aqui");
	JButton boton02 = new JButton("Aqui");
	JButton boton03 = new JButton("o Aqui");
	JButton botonReinciar = new JButton("Volver a Lanzar");

	// JLabel

	JLabel labelImagenOculta1 = new JLabel();
	JLabel labelImagenOculta2 = new JLabel();
	JLabel labelImagenOculta3 = new JLabel();

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaWars frame = new VentanaWars();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	public VentanaWars() {
		/**
		 * @JFrame
		 **/
		setTitle("FrikiWars_By_Mad");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// X Y W H
		setBounds(0, 0, 810, 635);
		Panel = new JPanel();
		Panel.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(Panel);

		/**
		 * @param_Control: Absoluto
		 */
		Panel.setLayout(null);

		// llamar a los botones para que ingresen a Action Listener
		boton01.addActionListener(this);
		boton02.addActionListener(this);
		boton03.addActionListener(this);
		botonReinciar.addActionListener(this);

		/** Boton de la izquierda **/

		boton01.setBackground(new Color(192, 192, 192));
		boton01.setFont(new Font("Bahnschrift", Font.BOLD, 12));

		// Posicion del boton y tamaño
		boton01.setBounds(31, 529, 225, 35);
		Panel.add(boton01);
		Panel.add(labelCromos01);
		Panel.setComponentZOrder(boton01, 0);
		/** Boton de la izquierda **/

		boton02.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		boton02.setBounds(287, 529, 225, 35);

		boton02.setBackground(new Color(192, 192, 192));
		Panel.add(boton02);
		/** Boton de la izquierda **/

		boton03.setFont(new Font("Bahnschrift", Font.BOLD, 12));
		boton03.setBounds(544, 529, 225, 31);

		boton03.setBackground(new Color(192, 192, 192));
		Panel.add(boton03);

		botonReinciar.setFont(new Font("Bahnschrift", Font.BOLD, 12));

		botonReinciar.setBounds(31, 563, 738, 30);
		Panel.add(botonReinciar);

		// Llamar a los metodos
		reiniciarJuego(labelFigurasPuestas);
		Cromos();
		inicializarImagenesOcultas(Ruta);
		mostrarImagenesOcultas();
		inicializarImagenes();
		mostrarImagenes();

		fondodePantalla();
		crearFichero();

	}

	public void inicializarImagenesOcultas(String ruta) {
		// Crear un array para almacenar las imágenes ocultas
		imagenesFigurasOcultas = new ImageIcon[10];

		// Rellenar el array con imágenes ocultas aleatorias
		for (int i = 0; i < 10; i++) {
			// Generar un índice aleatorio para seleccionar la imagen
			int numeroImagen = i + 1;

			// Construir la ruta de la imagen oculta
			String rutaImagenOculta1 = ruta + "FigurasErroneas\\" + "0" + numeroImagen + "bad.jpg";

			// Crear un ImageIcon y almacenarlo en el array
			imagenesFigurasOcultas[i] = new ImageIcon(rutaImagenOculta1);

		}
		// 2 indice

		for (int j = 0; j < 10; j++) {
			// Generar un índice aleatorio para seleccionar la imagen
			int numeroImagen = j + 1;

			// Construir la ruta de la imagen oculta
			String rutaImagenOculta2 = ruta + "FigurasAcertadas\\" + "0" + numeroImagen + "ok.jpg";

			// Crear un ImageIcon y almacenarlo en el array
			imagenesFigurasOcultas[j] = new ImageIcon(rutaImagenOculta2);

		}

	}

	public void mostrarImagenesOcultas() {
		// Genera índices aleatorios para seleccionar las imágenes
		int indiceImagenAcertada = (int) (Math.random() * 10);
		int indiceImagenErronea1 = (int) (Math.random() * 10);
		int indiceImagenErronea2 = (int) (Math.random() * 10);

		// Construye las rutas de las imágenes acertadas y erróneas
		String rutaImagenAcertada = Ruta + "FigurasAcertadas\\0" + (indiceImagenAcertada + 1) + "ok.jpg";
		String rutaImagenErronea1 = Ruta + "FigurasErroneas\\0" + (indiceImagenErronea1 + 1) + "bad.jpg";
		String rutaImagenErronea2 = Ruta + "FigurasErroneas\\0" + (indiceImagenErronea2 + 1) + "bad.jpg";

		// Crea ImageIcons con las imágenes obtenidas
		ImageIcon imagenAcertada = new ImageIcon(rutaImagenAcertada);
		ImageIcon imagenErronea1 = new ImageIcon(rutaImagenErronea1);
		ImageIcon imagenErronea2 = new ImageIcon(rutaImagenErronea2);

		// Asigna las imágenes a los labels de forma aleatoria
		
		
		int[] posiciones = { 1, 2, 3 }; // Índices para posiciones aleatorias
		int posicionesRamdom = random.nextInt(10);

		// Asigna las imágenes a los labels según las posiciones aleatorias
		switch (posiciones[0]) {
		case 1:
			labelImagenOculta1.setIcon(imagenAcertada);
			labelImagenOculta2.setIcon(imagenErronea1);
			labelImagenOculta3.setIcon(imagenErronea2);
			break;
		case 2:
			labelImagenOculta1.setIcon(imagenErronea1);
			labelImagenOculta2.setIcon(imagenAcertada);
			labelImagenOculta3.setIcon(imagenErronea2);
			break;
		case 3:
			labelImagenOculta1.setIcon(imagenErronea1);
			labelImagenOculta2.setIcon(imagenErronea2);
			labelImagenOculta3.setIcon(imagenAcertada);
			break;

		}
		System.out.println("test de posiciones 1 " + ":" + indiceImagenErronea1 + "\n" + imagenErronea1);
		System.out.println("test de posiciones 2 " + ":" + indiceImagenErronea2 + "\n" + imagenErronea2);

		// labelImagenOculta1.setIcon(ImgCromo);
		labelImagenOculta1.setBounds(31, 295, 255, 255);
		// labelImagenOculta1.setComponentZOrder(Panel,0);
		Panel.add(labelImagenOculta1);

		// labelImagenOculta1.setIcon(ImgCromo);
		labelImagenOculta2.setBounds(287, 295, 255, 255);
		Panel.add(labelImagenOculta2);

		// labelImagenOculta1.setIcon(ImgCromo);
		labelImagenOculta3.setBounds(544, 295, 255, 255);
		Panel.add(labelImagenOculta3);
	}

	// Método para mezclar un array de enteros

// borre el mouseaction

	public void fondodePantalla() {
		labelFondo.setIcon(Fondo);
		labelFondo.setBounds(0, 0, 810, 635);
		Panel.add(labelFondo);
		// labelFondo.getComponentZOrder(0);
	}

	public void Cromos() {
		labelCromos01.setIcon(ImgCromo);
		labelCromos01.setBounds(31, 295, 255, 255);
		// labelCromos01.getComponent(0);
		Panel.add(labelCromos01);

		labelCromos02.setIcon(ImgCromo);
		labelCromos02.setBounds(287, 295, 255, 255);
		Panel.add(labelCromos02);

		labelCromos03.setIcon(ImgCromo);
		labelCromos03.setBounds(544, 295, 255, 255);
		Panel.add(labelCromos03);

	}

	public void inicializarImagenes() {

		imagenFiguraAleatoriaPuesta = new ImageIcon[10];
		int i = 1;

		// imagenesPuestas
		for (i = 0; i < 10; i++) {
			String imagenAleatorio = "FiguraPuesta\\" + String.format("%02d", (i + 1)) + ".jpg";
			imagenFiguraAleatoriaPuesta[i] = new ImageIcon(Ruta + imagenAleatorio);

		}

	}

	ImageIcon imagenFigurasPuesta = new ImageIcon();

	public void mostrarImagenes() {

		// imagen puesta
		int figuraAleatoria = (int) (Math.random() * 10);

		String rutaFiguras = "FiguraPuesta\\" + "0" + figuraAleatoria + ".jpg";

		imagenFigurasPuesta = new ImageIcon(Ruta + rutaFiguras);
		System.out.println("\n Figuras Puestas testeo" + imagenFigurasPuesta + "\n");

		labelFigurasPuestas.setIcon(imagenFigurasPuesta);
		labelFigurasPuestas.setBounds(288, 14, 225, 255);
		Panel.add(labelFigurasPuestas);

		// System.out.println(labelFigurasPuestas);

	}

	// metodo de imagenes para asociar las imagenes con los botones

	// ------------------------------------------------------------------------------------

	private void verMensaje(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}

	
	private void reiniciarJuego(JLabel labelFigurasPuestas) {
		// Restablecer las imágenes y configuraciones iniciales directamente sobre los
		// componentes existentes

		Cromos();
		inicializarImagenesOcultas(Ruta);
		mostrarImagenesOcultas();
		inicializarImagenes();
		mostrarImagenes();

		fondodePantalla();

		numeroPartidas = 0;
		// Refrescar el contenido del panel
		if (numeroPartidas < 10) {
			numeroPartidas++;
			Panel.setEnabled(false);
			

		}else {
			verMensaje("Partida finalizada");
		}

		Panel.setComponentZOrder(labelFigurasPuestas, 0);

		Panel.repaint();

	}

	// Crear fichero

	public void crearFichero() {
		FileWriter fichero;
		String salidaFichero;

		System.out.println(
				" ----------------------------------------------------------------------------------------------------- \n Fichero del programa");
		salidaFichero = "Cromos Oculto izquierda" + "-" + "-" + "Cromos Oculto Centro" + "-" + "Cromo oculto Derecha"
				+ "-" + "Resultado " + "- " + aciertos;

		try {
			fichero = new FileWriter("datosFrikisWars.VDA", true);

			fichero.write(salidaFichero + fichero);
			fichero.close();
		} catch (Exception ex) {

			System.out.println("Mensaje de la excepción: " + ex.getMessage());
		}
		System.out.println(salidaFichero);
	}

	public void actionPerformed(ActionEvent event) {

		if (event.getSource() == boton01) {

			mostrarImagenesOcultas();
			Panel.setComponentZOrder(labelImagenOculta1, 0);
		
			if(labelImagenOculta1==labelFigurasPuestas) {
			aciertos=true;
		}
			
		

		}if (event.getSource() == boton02) {

			mostrarImagenesOcultas();
			Panel.setComponentZOrder(labelImagenOculta2, 0);
			

		} if (event.getSource() == boton03) {

			mostrarImagenesOcultas();
			Panel.setComponentZOrder(labelImagenOculta3, 0);
			

		}
		
		
		else {
			reiniciarJuego(labelFigurasPuestas);
		}

		/**
		 * if (event.getSource() == botonReinciar) {
		 * reiniciarJuego(labelFigurasPuestas); return; } int i = random.nextInt(10); //
		 * Verificar si la imagen oculta es igual a la imagen puesta if
		 * (event.getSource() == boton01 &&
		 * imagenesAcertadas[i].equals(imagenFigurasPuesta)) {
		 * verMensaje("¡Acertaste!"); reiniciarJuego(labelFigurasPuestas); aciertos =
		 * true; } else if (event.getSource() == boton02 &&
		 * imagenesFigurasOcultas[1].equals(imagenFigurasPuesta)) {
		 * verMensaje("¡Acertaste!"); reiniciarJuego(labelFigurasPuestas); aciertos =
		 * true; } else if (event.getSource() == boton03 &&
		 * imagenesFigurasOcultas[2].equals(imagenFigurasPuesta)) {
		 * verMensaje("¡Acertaste!"); reiniciarJuego(labelFigurasPuestas); aciertos =
		 * true; } else {
		 * 
		 * aciertos = false; }
		 **/
	}

}
